import Queue

eventqueue = Queue.Queue()
inputqueue = Queue.Queue()
outputqueue = Queue.Queue()
