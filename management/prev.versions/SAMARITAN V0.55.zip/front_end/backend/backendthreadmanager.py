def intitcorethread():
	import main
	main.main_loop()