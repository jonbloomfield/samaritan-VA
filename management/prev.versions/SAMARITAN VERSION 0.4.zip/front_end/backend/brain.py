print('Brain import: importing external modules\n Importing subprocess module')
import subprocess #for executing speaking on windows (unlikely to be used again as spninx doesnt work v well on windows)
print('importing yalm module')
import yaml #for passiing profile
print('importing os module')
import os
print('importing sys module')
import sys
print('enternal modules imported: commencing greymatter module import.')
from greymatter import general_conversations,time,weatherf
print('grey matter successfully imported')






'''profile = open('profile.yaml.default')
profile_data = yaml.safe_load(profile)      #load profile
profile.close()
name = profile_data[0]
city_name = profile_data[1]     #set profile vars'''

def brain(speech_text):     #main fuction for message passing
    words_of_message = speech_text.split() 
    def check_message(check):
        words_of_message = speech_text.split()
        if set(check).issubset(set(words_of_message)):  #function to check for subset *(NOTE: work in progress - must be optimised)*
            return True
        else:
            return False

    if check_message(['who','are', 'you']):
        output=general_conversations.who_are_you()
        tts(output)
        return output
    elif check_message(['how', 'i', 'look']) or check_message(['how', 'am', 'i']):  #list of things to check for (all current phrases )
        output=general_conversations.how_am_i()
        tts(output)
        return output
    elif check_message(['who', 'am', 'i']):
        output=general_conversations.who_am_i()
        tts(output)
        return output       
    elif check_message(['tell','time']) or check_message(['what','is','time']):
        output=time.tell_time(0)
        tts(output)
        return(output)
    elif check_message(['tell','date']) or check_message(['what','is','date']):
        output=time.tell_date(0)
        tts(output)
        return (output)
    elif check_message(['weather','now']) or check_message(['weather','outside']):
        output=weatherf.currentweather('oxford')
        tts(output)
        return outputw
    elif check_message(['temperature','now']) or check_message(['temperature','outside']):          # *NOTE: to be improved using NLTK *    
        tts(weatherf.getemperature('oxford'))
    elif check_message(['will','rain']) or check_message(['will','rainy']) or check_message(['will','raining']):
        tom=check_message('tomorrow')
        output=weatherf.feature_today('rain','oxford',tom)
        tts(output)
        return output
   
    elif check_message(['will','snow']) or check_message(['will','snowy']) or check_message(['will','snowing']):
        tom=check_message('tomorrow')
        output=weatherf.feature_today('snow','oxford',tom)
        tts(output)
        return output
    elif check_message(['will','clouds']) or check_message(['will','cloud']):
        tom=check_message('tomorrow')
        output=weatherf.feature_today('cloud','oxford',tom)
        tts(output)
        return output
    elif check_message(['will','fog']) or check_message(['will','foggy']):
        tom=check_message('tomorrow')
        output=weatherf.feature_today('fog','oxford',tom)
        tts(output)
        return output
    elif check_message(['will','sun']) or check_message(['will','sunny']) or check_message(['will','sunshine']):
        tom=check_message('tomorrow')
        output=weatherf.feature_today('sun','oxford',tom)
        tts(output)
        return output

    else:
        tts(general_conversations.undefined())



def tts(message):
    if(sys.platform=='linux2'):
	import linuxspeak
    print(message)
    linuxspeak.speak(message)             #function to speak output on multiple platforms
    return message

    if(sys.platform=='win32'):
        ttsengine='espeak'
        subprocess.call("espeak -s 130 -v +f2 " +message,shell=True)
        return message

print('brain function imported')
