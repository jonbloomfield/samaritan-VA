print('importing general conversations')
import random
from random import choice
def who_are_you():
    messages = [
        '" I am Samaritan, your personal assistant."',
        '"I am Samaritan, a soon be god."',
        '"I am all things past,present and future, but as of now I am your assistant."']    #random choice between these responses
                
    return(random.choice(messages))

def how_am_I():
    messages =[
        '"I don\'t yet have the ability to answer that question."']
    return(random.choice(messages))

def undefined():
    messages= ['"I dont know what that means!"',
                       '"My data banks do not nat an answer at this time."',
                       '"Insuffficient data."']
    return(random.choice(messages))

def who_am_i():
    messages= ['"You are admin"']
    return(random.choice(messages))
print('general conversations imported.')