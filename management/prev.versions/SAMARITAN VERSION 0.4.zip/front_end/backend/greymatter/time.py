print('importing time module')
from datetime import datetime
def tell_time(name):
	datestring=datetime.strftime(datetime.now(),'%H:%M')
	return("The time is " + datestring.replace(':',' ')) #pretty obvious

def tell_date(naame):
	datestring=datetime.strftime(datetime.now(), '%A:%d:%B:%Y')
	datestring=datestring.replace(':',' ')
	return ("The date is " + datestring) #pretty obvious
print('imported time time module')