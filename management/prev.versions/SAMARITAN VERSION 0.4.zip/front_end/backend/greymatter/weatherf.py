print('importing weather module')
import pyowm
import time
import datetime
owm = pyowm.OWM("b8650f4b75d74e34750b328562caf547")  # API key for open weather api
cacheweather=''

def checkcache():
	if(cacheweather==''): 
		return True
	timenow=time.time()
	cachetime=cacheweather.get_reference_time()		#samaritan keeps a recent weather cache to save on html request numbers and speed
	diff=timenow-cachetime
	if(diff>7200):return True 	#if defference is more than 3 hrs (when the free weather api service updates)
	else: return False

def currentweather(loc): #function for current weather
	global cacheweather
	if checkcache()==True:						#if new cache needed
		obs = owm.weather_at_place(loc+',uk')                    
		w = obs.get_weather()
		cacheweather=w
		return ('today, there will be '+w.get_detailed_status())
	elif checkcache()==False:
		return ('today, there will be '+cacheweather.get_detailed_status())	#if cache recent, pull from cache

def getemperature(loc):
	global cacheweather

	if checkcache()==True:
		obs = owm.weather_at_place(loc+',uk')                    # if new cache needed
		w = obs.get_weather()
		cacheweather=w
		temp=w.get_temperature(unit='celsius')
		tempmin=str(format(temp['temp_min']))		#pull temperature figures from raw data
		tempmin=tempmin[0:-2]
		tempmax=str(format(temp['temp_max']))
		tempmax=tempmax[0:-2]
		return ('today, the temperature will be between '+tempmin+' degrees and '+tempmax+' degrees')
	elif checkcache()==False:
		temp=cacheweather.get_temperature(unit='celsius')
		tempmin=str(format(temp['temp_min']))
		tempmin=tempmin[0:-2]								#pull temperature figures from raw data
		tempmax=str(format(temp['temp_max']))
		tempmax=tempmax[0:-2]
		print('cahce')
		return ('today, the temperature will be between '+tempmin+' degrees and '+tempmax+' degrees')

def feature_today(feature,loc,tomrrow): #function to tell if particular weather feature will be present in the next 24 hrs
	fc = owm.three_hours_forecast(loc+',uk')
	f = fc.get_forecast()
	lst = f.get_weathers()
	lst=lst[0:4] 	#*NOTE : update list for tomorrow, currently only getting 1st 24 hrs
	now=datetime.datetime.now()
	neededdate=now.strftime("%Y-%m-%d") 
	datestring=' today'
	if(tomrrow==True):	
		neededdate=datetime.date.today() + datetime.timedelta(days=1)	#can do ask for tomorrow or today. 
		datestring=' tomorrow'
	for i in lst:
		date=i.get_reference_time(timeformat='date')
		if(date.date()==neededdate):
			status=i.get_detailed_status()
			if set(feature).issubset(set(status)):
				return ('Yes, there will be '+feature+datestring)
		return ('No, there will not be '+feature+datestring)
print('weather module imported')