from kivy.app import App
from kivy.core.window import Window
from kivy.config import Config
from kivy.uix.gridlayout import GridLayout
from kivy.uix.boxlayout import BoxLayout
from kivy.properties import StringProperty
from kivy.uix.scrollview import ScrollView
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.lang import Builder

Builder.load_string("""
<Startup_Screen>:
    GridLayout:
        cols:1
        rows:2
        GridLayout:
            cols:2
            rows:1
            Button:
                id:initialise
                text:'START SAMARITAN'
                font_size:40
                on_press:root.startup()
            Button:
                id:enter_debug
                text:'debug mode'
                font_size:30
                #on_press:root.start_debug()
        ScrollView:
            Label:
                text_size: self.width, None
                font_size: 30
                size_hint_y: None
                height: self.texture_size[1]
                halign: 'left'
                valign: 'top'
                text:root.output

<newsceen>:
   
    GridLayout:
        cols:1
        rows:2
        GridLayout:
            cols:3
            rows:1
            spacing: '10dp'
            Button:
            TextInput:
                id: text_input
                multiline:False
                font_size: 30
                on_text_validate:root.inputtext()
            Button:
                id: input
                text: 'input'
                font_size: 30
                on_press: root.inputtext()

        ScrollView:
            Label:
                text_size: self.width, None
                font_size: 30
                size_hint_y: None
                height: self.texture_size[1]
                halign: 'left'
                valign: 'top'
                text:root.output
""")


class Startup_Screen(Screen):
	output=StringProperty()
	def startup(self):
		sm.current='mainsc'
		print('1')


class newsceen(Screen):
	tinput=StringProperty()
	output=StringProperty()
	def inputtext(self):
		self.output=self.output+'\n'+self.ids.text_input.text
		self.ids.text_input.text=''
sm = ScreenManager()
sm.add_widget(Startup_Screen(name='startup'))
sm.add_widget(newsceen(name='mainsc'))

class MainApp(App):

    def build(self):
    	self.title='Samaritan'
    	self.icon='logo.jpg'
        return sm

MainApp().run()

