inputlist=[1]
outputlist=[1]