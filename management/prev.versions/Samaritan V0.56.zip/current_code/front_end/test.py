import threading
import Queue
q = Queue.Queue()

def putq():
	global q
	global putthread
	while(True):
		inp=raw_input()
		q.put(inp)


def printq():
	flag=1
	while(True):
		while not q.empty():

			outp= q.get()
			if(outp=="0" and flag==1):
				print("pause")
				flag=0
			if(outp=="1" and flag==0):
				print("resume")
				flag==1
			if(flag==1):
				print(outp)
    		

putthread=threading.Thread(target=putq)
getthread=threading.Thread(target=printq)
putthread.start()
getthread.start()
