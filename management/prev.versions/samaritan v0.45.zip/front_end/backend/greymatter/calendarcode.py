import calendar
# Create a plain text calendar
c = calendar.TextCalendar(calendar.MONDAY)
idlist=[]

def setalarm(wordlist):
	t=1


def cselect():
	t=1

def current_month():
	str = c.formatmonth(2019, 9, 0, 0)
	print(str)

calendardict={
	C1:current_month

}