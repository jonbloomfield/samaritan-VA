print('startup begun.\nBeginning brain import')
import brain
print('brain import complete.\n importing speech recognition systems.')
import speechrec
print('speech recognition systems ready.  Commencing main loop.')

outputlist=[]
inputlist=[]



def main_loop():
	global outputlist
	brain.tts('"greetings admin."')
	man_flag=False
	while(True):
		outputlist=[]
		print('enter 1 to input or else enter manual (MANUAL) or debug mode (DEBUG)')
		inp=str(raw_input())
		if inp=="MANUAL":
			print("MANUAL MODE ON. TO EXIT MANUAL MODE, TYPE 'MANUAL OFF'")
			man_flag=True
		if inp=="MANUAL OFF":
			man_flag=False
		if inp=="DEBUG":
			debug.debugaccess()
		if inp=='1':
			outputlist.append(1)
			if man_flag==False:
				uinput=str(speechrec.inspeak())
			elif man_flag==True:
				print('enter manual input')
				man_inp=str(raw_input())
				uinput=man_inp
			output=brain.brain(uinput)
			outputlist.append(output)
        
main_loop()
