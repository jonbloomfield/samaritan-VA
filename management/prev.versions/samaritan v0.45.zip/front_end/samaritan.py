from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.properties import ObjectProperty
from kivy.uix.scrollview import ScrollView
from kivy.properties import StringProperty 
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.config import Config
Config.set('kivy', 'exit_on_escape', '0')
Config.set('graphics', 'width', '3840')
Config.set('graphics', 'height', '2160')

class StartupScreen(Screen):
    def exit(self):
    	App.get_running_app().stop()


class CoreRunningScreen(Screen):
	tinput=StringProperty()
	output=StringProperty()
	def inputtext(self):	#input text from text box to output scroll view
		self.output=self.output+'\n'+self.ids.minput.text
		self.ids.minput.text=''


class WindowManager(ScreenManager):
    pass

class samaritanfront(App):
	title = 'SAMARITAN'
	icon='logo.jpg'
	size=1300,700

if __name__ == "__main__":
	samaritanfront().run()
