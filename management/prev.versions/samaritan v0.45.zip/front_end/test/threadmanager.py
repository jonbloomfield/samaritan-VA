#!/usr/bin/python

import threading
import time
from threading import Lock, Thread


exitFlag = 0

class brainthread (threading.Thread):
   def __init__(self, threadID, name, counter):
   		threading.Thread.__init__(self)
   		self.threadID = threadID
   		self.name = name
   		from backend import main
   		backend.main.main_loop()

# Create new threads
thread1 = myThread(1, "Thread-1", 1)

# Start new Threads
thread1.start()